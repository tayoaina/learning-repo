terraform projects
=======
repo for terraform coursework, exercises & projects

