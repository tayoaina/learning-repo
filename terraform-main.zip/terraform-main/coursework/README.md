# terraform
<<<<<<< HEAD
terraform projects
=======
repo for terraform exercises and projects
>>>>>>> my-changes
